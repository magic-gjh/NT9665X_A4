#include "type.h"
#include "UIPlayInfo.h"

/*
static UINT32 ubSlideIndex = SLIDE_3SEC;
static UINT32 ubVMIndex = VM_ON;
static UINT32 ubDPOFPrtIndex = 0;
static UINT32 ubDPOFDateOnIndex = 0;

void Set_SlideIndex(UINT32 ubIndex)
{
    ubSlideIndex = ubIndex;
}

UINT32 Get_SlideIndex(void)
{
    return ubSlideIndex;
}

void Set_VoiceMemoIndex(UINT32 ubIndex)
{
    ubVMIndex = ubIndex;
}

UINT32 Get_VoiceMemoIndex(void)
{
    return ubVMIndex;
}

void Set_DPOFPrtIndex(UINT32 ubIndex)
{
    ubDPOFPrtIndex = ubIndex;
}

UINT32 Get_DPOFPrtIndex(void)
{
    return ubDPOFPrtIndex;
}

void Set_DPOFDateOnIndex(UINT32 ubIndex)
{
    ubDPOFDateOnIndex = ubIndex;
}

UINT32 Get_DPOFDateOnIndex(void)
{
    return ubDPOFDateOnIndex;
}

DDX_INDEX ddx_Slide = {Set_SlideIndex,Get_SlideIndex};
DDX_INDEX ddx_VoiceMemo = {Set_VoiceMemoIndex,Get_VoiceMemoIndex};
*/
