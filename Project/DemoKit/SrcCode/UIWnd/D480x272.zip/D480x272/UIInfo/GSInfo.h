#ifndef _GSINFO_H_
#define _GSINFO_H_

extern void     Load_GSInfo(void);
extern void     Save_GSInfo(void);
extern void     Init_GSInfo(void);
extern void     Update_GSInfo(UINT32* pGSCalData);

#endif //_GSINFO_H_