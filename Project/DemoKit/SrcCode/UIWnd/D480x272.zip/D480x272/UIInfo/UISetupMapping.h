extern UINT32 Get_LanguageValue(UINT32 uiIndex);
