#ifndef _MENUMOVIE_H
#define _MENUMOVIE_H


extern TM_MENU gMovieMenu;
extern TM_MENU gMovieVivilinkMenu;

extern TM_OPTION gTM_OPTIONS_MOVIE_SIZE[MOVIE_SIZE_ID_MAX];
#endif
